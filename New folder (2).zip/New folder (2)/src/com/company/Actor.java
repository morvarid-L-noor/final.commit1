package com.company;

/**
 * Created by Movarid on 12/29/2020.
 */
public interface Actor {
    public void move();
}
