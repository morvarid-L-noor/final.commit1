package com.company.ball;

import com.company.Element;
import com.company.Sun;
import com.company.Zombie;

import java.awt.event.*;
import java.io.*;
import java.security.SecureRandom;
import java.util.ArrayList;

public class GameState implements Serializable{

    public int locX, locY, diam;
    public boolean gameOver , start;
    private String playerName;
    private  int playersSuns;
    enum type{ hard , normal}
    private  type type;
    private boolean mute;
    private Element[][] elements;
    private boolean keyUP, keyDOWN, keyRIGHT, keyLEFT;
    private boolean mousePress;
    private int mouseX, mouseY;
    private KeyHandler keyHandler;
    private MouseHandler mouseHandler;
    private ArrayList<Zombie> zombies = new ArrayList<>();
    private  int waveNum ;
    private  long gameStartTime;
    private  boolean row1Zombie = false;
    private  boolean row2Zombie = false;
    private  boolean row3Zombie = false;
    private  boolean row4Zombie = false;
    private  boolean row5Zombie = false;

    public GameState(){
        locX = 100;
        locY = 100;
        diam = 32;
        gameOver = false;
        start = false;
        //
        keyUP = false;
        keyDOWN = false;
        keyRIGHT = false;
        keyLEFT = false;
        //
        mousePress = false;
        mouseX = 0;
        mouseY = 0;
        //
        keyHandler = new KeyHandler();
        mouseHandler = new MouseHandler();
        elements = new Element[5][9];
        playersSuns = 50;
        gameStartTime = System.currentTimeMillis();
    }

    public  void  checkGameOver(){
        for(Zombie z : zombies){
            if(z.arrivesHome() == true){
                gameOver = true;
            }
        }
    }
    public String getPlayerName() {
        return playerName;
    }

    public void setPlayerName(String playerName) {
        this.playerName = playerName;
        addToFile();
    }
    public GameState.type getType() {
        return type;
    }

    public void setType(GameState.type type) {
        this.type = type;
    }

    public boolean isMute() {
        return mute;
    }

    public void setMute(boolean mute) {
        this.mute = mute;
    }

    public Element[][] getElements() {
        return elements;
    }

    public void setElements(Element[][] elements) {
        this.elements = elements;
    }

    public void addElement(int row , int column, Element element){
        elements[row][column] = element;
    }

    public  void  randomZombie() throws Exception {
        int random = new SecureRandom().nextInt(3);
        if(random == 0) {
            zombies.add(new Zombie(Zombie.type.normal));
        }else  if(random == 1) {
            zombies.add(new Zombie(Zombie.type.coneHead));
        }else  if(random == 2) {
            zombies.add(new Zombie(Zombie.type.bucketHead));
        }
    }
    /**
     * The method which updates the game state.
     */
    public void update() throws Exception {
        checkGameOver();
         //stop & bomb  888888888888888888888888888888888888888888888888888888888888888888888888888888888888888888888888

        if((System.currentTimeMillis() - gameStartTime) > 50000 &&  (System.currentTimeMillis() - gameStartTime) < 200000 ){
            if((System.currentTimeMillis() - gameStartTime) % 30000 == 0) {
                randomZombie();
            }

        }else if((System.currentTimeMillis() - gameStartTime) >= 200000 && (System.currentTimeMillis() - gameStartTime) < 380000 ) {
            if((System.currentTimeMillis() - gameStartTime) % 30000 == 0) {
                randomZombie();
                randomZombie();
            }

        }else if((System.currentTimeMillis() - gameStartTime) >=  380000 && (System.currentTimeMillis() - gameStartTime) < 530000 ) {
            if((System.currentTimeMillis() - gameStartTime) % 25000 == 0) {
                randomZombie();
                randomZombie();
            }

        }



        if (mousePress) {
            locY = mouseY - diam / 2;
            locX = mouseX - diam / 2;
        }
        if (keyUP)
            locY -= 8;
        if (keyDOWN)
            locY += 8;
        if (keyLEFT)
            locX -= 8;
        if (keyRIGHT)
            locX += 8;

        locX = Math.max(locX, 0);
        locX = Math.min(locX, GameFrame.GAME_WIDTH - diam);
        locY = Math.max(locY, 0);
        locY = Math.min(locY, GameFrame.GAME_HEIGHT - diam);
    }


    public KeyListener getKeyListener() {
        return keyHandler;
    }
    public MouseListener getMouseListener() {
        return mouseHandler;
    }
    public MouseMotionListener getMouseMotionListener() {
        return mouseHandler;
    }

    class KeyHandler extends KeyAdapter {

        @Override
        public void keyPressed(KeyEvent e) {
            switch (e.getKeyCode())
            {
                case KeyEvent.VK_UP:
                    keyUP = true;
                    break;
                case KeyEvent.VK_DOWN:
                    keyDOWN = true;
                    break;
                case KeyEvent.VK_LEFT:
                    keyLEFT = true;
                    break;
                case KeyEvent.VK_RIGHT:
                    keyRIGHT = true;
                    break;
                case KeyEvent.VK_ESCAPE:
                    gameOver = true;
                    break;
                case KeyEvent.VK_ENTER:
                    start = true;
                    break;
            }
        }

        @Override
        public void keyReleased(KeyEvent e) {
            switch (e.getKeyCode())
            {
                case KeyEvent.VK_UP:
                    keyUP = false;
                    break;
                case KeyEvent.VK_DOWN:
                    keyDOWN = false;
                    break;
                case KeyEvent.VK_LEFT:
                    keyLEFT = false;
                    break;
                case KeyEvent.VK_RIGHT:
                    keyRIGHT = false;
                    break;
            }
        }

    }

    /**
     * The mouse handler.
     */
    class MouseHandler extends MouseAdapter {

        @Override
        public void mousePressed(MouseEvent e) {
            mouseX = e.getX();
            mouseY = e.getY();
            mousePress = true;
        }

        @Override
        public void mouseReleased(MouseEvent e) {
            mousePress = false;
        }

        @Override
        public void mouseDragged(MouseEvent e) {
            mouseX = e.getX();
            mouseY = e.getY();
        }
    }
    void addToFile(){
        String studentDir = "C:\\Users\\Movarid\\Desktop\\finalProject\\games";
        try(FileOutputStream fileOutputStream = new FileOutputStream(studentDir + File.separator+this.playerName)) {
            ObjectOutputStream objectOutputStream = new ObjectOutputStream(fileOutputStream);
            objectOutputStream.writeObject(this);
        } catch (IOException e) {
            e.printStackTrace();
        }
    }
}

