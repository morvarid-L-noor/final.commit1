package com.company;

import javax.imageio.ImageIO;
import java.io.File;
import java.io.IOException;
import java.util.ArrayList;
public class Pea extends Plant {
    protected ArrayList<Bullet> bullets = new ArrayList<>();
    private enum Type{ peaShooter , snowPea}
    private Type peaType;
    public Pea(int x , int y , Type peaType) throws IOException {
        setX(x);
        setY(y);
        this.peaType = peaType;
        setFields();
    }
    private void setFields() throws IOException {
        if(peaType == Type.peaShooter){
            this.cost = 100;
            this.power = 70;
            //img = ImageIO.read(new File("images\\freezepea.png"));   888888888888888888888888888888888888888888888
        }else if(peaType == Type.snowPea){
            this.cost = 175;
            this.power = 100;
            img = ImageIO.read(new File("images\\freezepea.png"));
        }
    }
    public ArrayList<Bullet> getBullets(){
        return bullets;
    }
}
