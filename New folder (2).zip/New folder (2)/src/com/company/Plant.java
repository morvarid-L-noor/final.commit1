package com.company;
public class Plant extends Element{
    protected int cost ;
    protected   int power ;

    public Plant(){

    }
}
